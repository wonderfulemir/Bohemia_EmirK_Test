README - for the file Code.cpp where everything is done.
Firstly, I would like to say that it was quite a hard one to work through my job, and find time to properly setup the solution, make files properly, include them and make it a better read. I was kind of falling behind on my job, and on this task so I decided to start from scratch and do it faster through an online code editor, that's why everything you saw is in just one file. 

Time per feature:

1. Implement a generic ObjectManager - All the points for this was done in 3 hours more or less for every feature (including writing the classes that were not inherited from these classes)

2. Implement EntityAction and EntityActionManager - Around 1-2 hours. Including fixing bugs from the previous revision.

3. Present system on minimum two Entities - that's the only test that I managed to write today for about 2-3 hours. I also needed to fix the bugs from the previous 2 points.

Again, sorry for taking my time, I did not realize how hard it can be doing game developer jobs, while trying to go to another company.

